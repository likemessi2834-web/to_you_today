package com.example.to_you_today

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
